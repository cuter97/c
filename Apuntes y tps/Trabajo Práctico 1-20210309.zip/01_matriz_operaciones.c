#include <stdio.h>
#include <stdlib.h>
#define MAX 20


/*********************************************************************/
/*                 PROTOTIPOS DE FUNCIONES                           */
/*********************************************************************/
int matriz_inicializar_rnd(int matriz[MAX][MAX], int filas, int columnas);
int matriz_inicializar_identidad(int matriz[MAX][MAX], int filas, int columnas);
int matriz_inicializar_simetrica(int matriz[MAX][MAX], int filas, int columnas);
int matriz_imprimir_por_filas(int matriz[MAX][MAX], int filas, int columnas);
int matriz_imprimir_por_columnas(int matriz[MAX][MAX], int filas, int columnas);
int matriz_suma(int A[MAX][MAX], int B[MAX][MAX],int C[MAX][MAX], int filas, int columnas);
int matriz_resta(int A[MAX][MAX], int B[MAX][MAX],int C[MAX][MAX], int filas, int columnas);
int matriz_producto(int A[MAX][MAX], int B[MAX][MAX],int C[MAX][MAX], int filas, int columnas);
int matriz_es_simetrica(int A[MAX][MAX], int filas, int columnas);
int matriz_es_diagonal_superior(int A[MAX][MAX],int filas, int columnas);
int matriz_es_diagonal_inferior(int A[MAX][MAX],int filas, int columnas);
int matriz_son_iguales(int A[MAX][MAX],int B[MAX][MAX], int filasA, int columnasA, int filasB, int columnasB);




int main()
{
  int filas, columnas;
  int matA[MAX][MAX], matB[MAX][MAX], matC[MAX][MAX];

  printf("Ingrese las dimensiones de la matriz (filas y columnas) \n");
  scanf("%d %d", &filas, &columnas); // dimensiones logicas que no deben superar MAX

  if ((filas > MAX) || (columnas > MAX)) {
      // dimension logica supera a la fisica
      printf("La dimension logica debe ser menor a la fisica \n");
      exit (-1);
  }
  else {
      // dimension logica correcta
      matriz_inicializar_rnd(matA, filas, columnas);
      matriz_inicializar_identidad(matB, filas, columnas);
      matriz_producto(matA,matB,matC,filas,columnas);
     
      if(matriz_son_iguales(matA,matC, filas,columnas,filas, columnas)) 
        printf("Producto correcto\n");
      else
        printf("Producto incorrecto\n");

      matriz_imprimir_por_filas(matA, filas, columnas);
      printf("\n");
      matriz_imprimir_por_columnas(matB, filas, columnas);

      printf("\n Tamano matriz: %lu tam int: %lu \n", sizeof(matA), sizeof(int));
   }
    
   return(0);
}





/*********************************************************************/
/*             IMPLEMENTACION DE FUNCIONES                           */
/*********************************************************************/
// inicializa parametro matriz con valores aleatorios con valores de 0..99
int matriz_inicializar_rnd(int matriz[MAX][MAX], int filas, int columnas){

  return 0;
}

// inicializa matriz como matriz identidad
int matriz_inicializar_identidad(int matriz[MAX][MAX], int filas, int columnas){

  return 0;
}

// iniciliza matriz con valores aleatorios pero simetrica
int matriz_inicializar_simetrica(int matriz[MAX][MAX], int filas, int columnas){

  return 0;
}

// imprime matriz por filas
int matriz_imprimir_por_filas(int matriz[MAX][MAX], int filas, int columnas){

  return 0;
}

// imprime matriz por columnas
int matriz_imprimir_por_columnas(int matriz[MAX][MAX], int filas, int columnas){

  return 0;
}

// suma matrices. A + B = C. Se asume que A, B y C son del mismo tamaño
int matriz_suma(int A[MAX][MAX], int B[MAX][MAX],int C[MAX][MAX], int filas, int columnas){

  return 0;
}

// resta matrices A - B = C. Se asume que A, B y C son del mismo tamaño
int matriz_resta(int A[MAX][MAX], int B[MAX][MAX],int C[MAX][MAX], int filas, int columnas){

  return 0;
}

// producto de matrices A * B = C. Se asume que A, B y C son del mismo tamaño
int matriz_producto(int A[MAX][MAX], int B[MAX][MAX],int C[MAX][MAX], int filas, int columnas){

  return 0;
}

// retorna TRUE si A es simetricas, FALSE caso contrario
int matriz_es_simetrica(int A[MAX][MAX], int filas, int columnas){

  return 0;
}

// retorna TRUE si A es matriz diagonal superior, FALSE caso contrario
int matriz_es_diagonal_superior(int A[MAX][MAX],int filas, int columnas){

  return 0;
}

// retorna TRUE si A es matriz diagonal inferior, FALSE caso contrario
int matriz_es_diagonal_inferior(int A[MAX][MAX],int filas, int columnas){

  return 0;
}

// retorna TRUE si A y B son iguales, FALSE caso contrario
int matriz_son_iguales(int A[MAX][MAX],int B[MAX][MAX], int filasA, int columnasA, int filasB, int columnasB){

  return 0;
}



